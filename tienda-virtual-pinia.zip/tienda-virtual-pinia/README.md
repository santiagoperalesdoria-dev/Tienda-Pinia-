# Verde Vivo — Tienda virtual con Vue 3 + Pinia

## Instalación
1. Abre esta carpeta en Visual Studio Code.
2. En la terminal ejecuta `npm install`.
3. Ejecuta `npm run dev` y abre la dirección local que indique Vite (normalmente http://localhost:5173).

## Arquitectura
- `src/main.js`: instala Pinia con `app.use(createPinia())`.
- `src/stores/tienda.js`: store `useTiendaStore`, con productos, carrito, factura, contador y acciones.
- `src/App.vue`: consume el store con `useTiendaStore()` y `storeToRefs()`.
- `src/components/`: encabezado, catálogo, tarjeta, carrito, factura y pie de página.

## Acciones del store
`agregarProducto`, `incrementar`, `decrementar`, `eliminar`, `finalizarCompra`, `nuevaCompra`.

La tienda incluye ocho productos, descuentos, búsqueda, filtros, carrito y factura con IVA del 19 %. Los valores se muestran en pesos colombianos. Las imágenes externas requieren internet.

<script setup>
import { computed, ref } from 'vue'
import { storeToRefs } from 'pinia'
import { useTiendaStore } from './stores/tienda'
import AppHeader from './components/AppHeader.vue'
import ListaProductos from './components/ListaProductos.vue'
import CarritoCompra from './components/CarritoCompra.vue'
import FacturaCompra from './components/FacturaCompra.vue'
import AppFooter from './components/AppFooter.vue'

const tienda = useTiendaStore()
const { nombreTienda, contacto, productos, carrito, mostrarFactura, numeroFactura, aviso, cantidadItems, categorias } = storeToRefs(tienda)
const anio = new Date().getFullYear()
const categoriaActiva = ref('Todos')
const busqueda = ref('')
const productosFiltrados = computed(() => productos.value.filter(p => {
  const categoriaOk = categoriaActiva.value === 'Todos' || p.categoria === categoriaActiva.value
  const termino = busqueda.value.trim().toLocaleLowerCase('es')
  return categoriaOk && (!termino || `${p.descripcion} ${p.detalle} ${p.categoria}`.toLocaleLowerCase('es').includes(termino))
}))
function verCarrito() { document.getElementById('carrito')?.scrollIntoView({behavior:'smooth', block:'start'}) }
</script>

<template>
  <div class="site-shell">
    <AppHeader
      :nombre-tienda="nombreTienda"
      :cantidad-items="cantidadItems"
      @ver-carrito="verCarrito"
    />

    <main>
      <section class="hero">
        <div class="hero-copy">
          <p class="eyebrow"><span class="eyebrow-dot"></span> Una forma más simple de elegir</p>
          <h1>Pequeños detalles.<br /><span>Grandes experiencias.</span></h1>
          <p class="hero-description">Tecnología y accesorios seleccionados para acompañarte en cada momento.</p>
          <a class="hero-link" href="#catalogo">Explorar productos <span aria-hidden="true">↗</span></a>
          <div class="hero-trust">
            <span><span class="check">✓</span> Compra fácil</span>
            <span><span class="check">✓</span> Productos seleccionados</span>
          </div>
        </div>
        <div class="hero-art" aria-label="Audífonos y accesorios tecnológicos">
          <div class="hero-orbit orbit-one"></div>
          <div class="hero-orbit orbit-two"></div>
          <div class="hero-sticker"><span>Selección</span><strong>para ti</strong></div>
          <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1100&q=90" alt="Audífonos modernos" />
          <div class="hero-caption"><span class="caption-mark">✳</span><span><strong>Encuentra tu favorito</strong><small>Ideas para todos los días</small></span></div>
        </div>
        <div class="hero-number">01 <span>/ COLECCIÓN</span></div>
      </section>

      <section class="benefits" aria-label="Beneficios de la tienda">
        <div class="benefit"><span class="benefit-icon">◇</span><span><strong>Selección cuidada</strong><small>Productos para tu día a día</small></span></div>
        <div class="benefit"><span class="benefit-icon">↗</span><span><strong>Compra sencilla</strong><small>Agrega y revisa tu carrito</small></span></div>
        <div class="benefit"><span class="benefit-icon">♡</span><span><strong>Hecho para ti</strong><small>Encuentra algo que te guste</small></span></div>
      </section>

      <section id="catalogo" class="catalog-section">
        <div class="section-heading">
          <div>
            <p class="eyebrow">LA COLECCIÓN</p>
            <h2>Descubre tus <em>favoritos.</em></h2>
            <p class="section-subtitle">Una selección de tecnología y accesorios para tu rutina.</p>
          </div>
          <div class="catalog-count"><strong>{{ productosFiltrados.length.toString().padStart(2, '0') }}</strong><span> productos</span></div>
        </div>

        <div class="catalog-tools">
          <div class="category-list" aria-label="Filtrar por categoría">
            <button
              v-for="categoria in categorias"
              :key="categoria"
              class="category-chip"
              :class="{ active: categoriaActiva === categoria }"
              @click="categoriaActiva = categoria"
            >{{ categoria }}</button>
          </div>
          <label class="search-box">
            <span aria-hidden="true">⌕</span>
            <input v-model="busqueda" type="search" placeholder="Buscar producto..." aria-label="Buscar producto" />
          </label>
        </div>

        <ListaProductos :productos="productosFiltrados" @agregar-producto="tienda.agregarProducto" />
        <div v-if="productosFiltrados.length === 0" class="empty-search">
          <span>⌕</span><strong>No encontramos productos</strong><p>Prueba con otro nombre o categoría.</p>
          <button class="text-button" @click="busqueda = ''; categoriaActiva = 'Todos'">Ver todos los productos</button>
        </div>
      </section>

      <section class="promo-strip">
        <div class="promo-symbol">✳</div>
        <div><p class="eyebrow">UN BUEN HALLAZGO TE ESPERA</p><h2>Tu próxima cosa favorita<br />puede estar aquí.</h2></div>
        <a href="#catalogo">Ver colección <span>↗</span></a>
        <div class="promo-decoration">VV.</div>
      </section>

      <section id="carrito" class="cart-section">
        <div class="section-heading cart-heading">
          <div><p class="eyebrow">TU SELECCIÓN</p><h2>El carrito <em>de compra.</em></h2><p class="section-subtitle">Revisa tus productos antes de finalizar.</p></div>
          <div class="cart-count"><span>{{ cantidadItems.toString().padStart(2, '0') }}</span> unidades</div>
        </div>
        <CarritoCompra
          :items="carrito"
          @incrementar="tienda.incrementar"
          @decrementar="tienda.decrementar"
          @eliminar="tienda.eliminar"
          @finalizar-compra="tienda.finalizarCompra"
        />
      </section>

      <section v-if="mostrarFactura" id="factura" class="invoice-section">
        <FacturaCompra
          :items="carrito"
          :numero-factura="String(numeroFactura).padStart(5, '0')"
          :fecha="new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' })"
          @nueva-compra="tienda.nuevaCompra"
        />
      </section>
    </main>

    <div v-if="aviso" class="toast" role="status"><span>✓</span>{{ aviso }}</div>
    <AppFooter :nombre-tienda="nombreTienda" :anio="anio" :contacto="contacto" />
  </div>
</template>
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

export const useTiendaStore = defineStore('tienda', () => {
  const nombreTienda = 'Verde Vivo'
  const contacto = 'hola@verdevivo.co'
  const productos = ref([
    { id: 1, imagen: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=900&q=85', descripcion: 'Audífonos inalámbricos', detalle: 'Sonido envolvente · Bluetooth 5.3', valor: 189900, descuento: 20, categoria: 'Audio', etiqueta: 'Más vendido' },
    { id: 2, imagen: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85', descripcion: 'Reloj inteligente', detalle: 'Monitoreo diario · Resistente al agua', valor: 249900, descuento: 15, categoria: 'Accesorios', etiqueta: '' },
    { id: 3, imagen: 'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=900&q=85', descripcion: 'Parlante portátil', detalle: 'Audio potente · 12 h de batería', valor: 159900, descuento: 10, categoria: 'Audio', etiqueta: 'Oferta' },
    { id: 4, imagen: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=85', descripcion: 'Portátil ultradelgado', detalle: 'Rendimiento para estudiar y crear', valor: 2899900, descuento: 12, categoria: 'Tecnología', etiqueta: '' },
    { id: 5, imagen: 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=900&q=85', descripcion: 'Cámara compacta', detalle: 'Captura tus momentos favoritos', valor: 429900, descuento: 0, categoria: 'Tecnología', etiqueta: '' },
    { id: 6, imagen: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=900&q=85', descripcion: 'Audífonos de diadema', detalle: 'Acolchados · Graves profundos', valor: 219900, descuento: 18, categoria: 'Audio', etiqueta: '' },
    { id: 7, imagen: 'https://images.unsplash.com/photo-1542291026-7eec264c27e0?auto=format&fit=crop&w=900&q=85', descripcion: 'Tenis urbanos', detalle: 'Diseño ligero para todos los días', valor: 279900, descuento: 25, categoria: 'Estilo', etiqueta: 'Precio especial' },
    { id: 8, imagen: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85', descripcion: 'Auriculares premium', detalle: 'Diseño cómodo y sonido nítido', valor: 199900, descuento: 8, categoria: 'Audio', etiqueta: '' }
  ])
  const carrito = ref([])
  const mostrarFactura = ref(false)
  const numeroFactura = ref(1)
  const aviso = ref('')
  const cantidadItems = computed(() => carrito.value.reduce((t, i) => t + i.cantidad, 0))
  const categorias = computed(() => ['Todos', ...new Set(productos.value.map(p => p.categoria))])
  function agregarProducto(producto) {
    const encontrado = carrito.value.find(i => i.producto.id === producto.id)
    carrito.value = encontrado ? carrito.value.map(i => i.producto.id === producto.id ? {...i, cantidad:i.cantidad+1} : i) : [...carrito.value, {producto, cantidad:1}]
    mostrarFactura.value = false
    aviso.value = `${producto.descripcion} se agregó al carrito`
    window.setTimeout(() => { aviso.value = '' }, 2400)
  }
  function incrementar(id) { carrito.value = carrito.value.map(i => i.producto.id === id ? {...i, cantidad:i.cantidad+1} : i) }
  function decrementar(id) { carrito.value = carrito.value.map(i => i.producto.id === id ? {...i, cantidad:i.cantidad-1} : i).filter(i => i.cantidad > 0) }
  function eliminar(id) { carrito.value = carrito.value.filter(i => i.producto.id !== id) }
  function finalizarCompra() { if (carrito.value.length) mostrarFactura.value = true }
  function nuevaCompra() { carrito.value = []; mostrarFactura.value = false; numeroFactura.value += 1; window.scrollTo({top:0,behavior:'smooth'}) }
  return { nombreTienda, contacto, productos, carrito, mostrarFactura, numeroFactura, aviso, cantidadItems, categorias, agregarProducto, incrementar, decrementar, eliminar, finalizarCompra, nuevaCompra }
})
